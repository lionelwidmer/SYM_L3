package ch.heig.sym_labo3.utils;

@FunctionalInterface
public interface NFCFunction{
    void method(String a);
}
